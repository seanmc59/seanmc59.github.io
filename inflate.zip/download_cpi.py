#!/usr/bin/env python
# coding: utf-8

# In[17]:


'''Requests Urban CPI from the BLS Public API and converts to Stata file.
7/13/21 Sean McCulloch <sean_mcculloch@brown.edu>'''

import requests
import json

import pandas as pd
import numpy as np

from datetime import datetime
import sys

adopath =  str(sys.argv[1])

#Query to current year, whatever that may be.
curyear = datetime.today().year


# In[18]:


#BLS API caps requests at 10 years for public api.
#25 Queries per day how do they know who's querying
def request_cpi(startyr, endyr):
    headers = {'Content-type': 'application/json'}
    data = json.dumps({"seriesid": ['CUUR0000SA0'],"startyear":str(startyr), "endyear":str(endyr)})

    p = requests.post('https://api.bls.gov/publicAPI/v1/timeseries/data/', data=data, headers=headers)
    json_data = json.loads(p.text)

    observations = json_data['Results']['series'][0]['data']

    df = pd.json_normalize(observations)
    df = df[['year', 'period', 'periodName', 'value']]
    
    return df


# In[19]:



#------------------------------------------------


# In[21]:


cpi_df = request_cpi(1913, 1919)


# In[22]:


for i in range(1920, 2020, 10): 
    j = i + 9
    print('start year: ' + str(i) + ', end year: ' + str(j))
    df = request_cpi(i, j)
    
    cpi_df = cpi_df.append(df)


# In[33]:


#Get newest cpis 
updatetime = curyear - 2020
numqueries = round(updatetime / 10) + 1

for i in range(1, numqueries + 1):
    if 2020 + (i-1)*10 >= curyear:
        print('reached current year')
    else: 
        endyear = min(2020 + i*10, curyear)
        print("Request: " + str(2020 + (i-1)*10) + " to " + str(endyear))
        cpi_df = cpi_df.append(request_cpi(2020 + (i-1)*10, endyear))


# In[34]:


#----------------------
cpi_export_df = cpi_df.copy()
cpi_export_df['year'] = cpi_export_df['year'].astype(int)
cpi_export_df['value'] = cpi_export_df['value'].astype(float)

cpi_export_df['period'] = cpi_export_df['period'].str[1:]
cpi_export_df['period'] = cpi_export_df['period'].astype(int)


# In[35]:


cpi_export_df = cpi_export_df.rename(columns={'period':'month'})


# In[36]:


cpi_export_df


# In[37]:


#---------------
#Sort, make average quarters, halves, annual and then reappend
cpi_export_df['periodtype'] = 'M'

#Make quarters, halves
conditions = [
    (cpi_export_df['month'] >= 1) & (cpi_export_df['month'] <= 3),
    (cpi_export_df['month'] >= 4) & (cpi_export_df['month'] <= 6),
    (cpi_export_df['month'] >= 7) & (cpi_export_df['month'] <= 9),
    (cpi_export_df['month'] >= 10) & (cpi_export_df['month'] <= 12)
]
choices = [1, 2, 3, 4]
cpi_export_df['quarter'] = np.select(conditions, choices, default=-1)

conditions = [
    (cpi_export_df['month'] >= 1) & (cpi_export_df['month'] <= 6),
    (cpi_export_df['month'] >= 7) & (cpi_export_df['month'] <= 12)
]
choices = [1, 2]
cpi_export_df['half'] = np.select(conditions, choices, default=-1)

cpi_export_df


# In[38]:


#Collapse to year, half, quarter then append those as new obs
cpi_export_df['counter'] = 1
#Years
cpi_avg_ann = cpi_export_df.groupby('year')[['value', 'counter']].agg({'value':'mean', 'counter':'sum'}).reset_index()
cpi_avg_ann['periodtype'] = 'Y'
cpi_avg_ann = cpi_avg_ann[cpi_avg_ann['counter'] == 12]
#----------------
#Halves
cpi_avg_half = cpi_export_df.groupby(['year', 'half'])[['value', 'counter']].agg({'value':'mean', 'counter':'sum'}).reset_index()
cpi_avg_half['periodtype'] = 'H'
cpi_avg_half = cpi_avg_half[cpi_avg_half['counter'] == 6]
#----------------
#Quarters
cpi_avg_quarter = cpi_export_df.groupby(['year', 'quarter'])[['value', 'counter']].agg({'value':'mean', 'counter':'sum'}).reset_index()
cpi_avg_quarter['periodtype'] = 'Q'
cpi_avg_quarter = cpi_avg_quarter[cpi_avg_quarter['counter'] == 3]


# In[39]:


cpi_export_df = cpi_export_df.append(cpi_avg_ann)
cpi_export_df = cpi_export_df.append(cpi_avg_half)
cpi_export_df = cpi_export_df.append(cpi_avg_quarter)


# In[40]:


#Create year + period type + period num
cpi_export_df['timeperiod'] = cpi_export_df['year'].astype(str) + cpi_export_df['periodtype'] 

for v in ['month', 'quarter', 'half']:
    cpi_export_df[v + '_s'] =  cpi_export_df[v].astype('Int64').astype(str)
    cpi_export_df[v + '_s'] = cpi_export_df[v + '_s'].str.zfill(2)

cpi_export_df = cpi_export_df.reset_index()
cpi_export_df.loc[cpi_export_df['periodtype'] == 'M', 'timeperiod'] = cpi_export_df['timeperiod'] + cpi_export_df['month_s']
cpi_export_df.loc[cpi_export_df['periodtype'] == 'Q', 'timeperiod'] = cpi_export_df['timeperiod'] + cpi_export_df['quarter_s']
cpi_export_df.loc[cpi_export_df['periodtype'] == 'H', 'timeperiod'] = cpi_export_df['timeperiod'] + cpi_export_df['half_s']


# In[41]:


#----------------------------
cpi_export_df.to_stata(adopath + r"/cpi.dta", version = 117)


# In[ ]:




